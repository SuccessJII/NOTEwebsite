import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

const DB_PATH = path.join(process.cwd(), 'db.json');

export interface Code {
  id: string;
  code: string;
  type: 'one_time' | 'days' | 'never' | 'hours';
  value?: number; // days or hours
  createdAt: string;
  usedBy?: string[];
  expiresAt?: string;
  maxUses?: number;
  sessionDurationType?: 'hours' | 'days' | 'never';
  sessionDurationValue?: number;
}

export interface Note {
  id: string;
  title: string;
  subject: string;
  type: 'file' | 'link';
  url?: string;
  filename?: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  username: string;
  text?: string;
  fileUrl?: string;
  fileName?: string;
  createdAt: string;
  isDeleted?: boolean;
}

export interface DB {
  settings: {
    panicMode: boolean;
    aiDisabled?: boolean;
    chatDisabled?: boolean;
  };
  codes: Code[];
  notes: Note[];
  messages: ChatMessage[];
}

const defaultDB: DB = {
  settings: { panicMode: false, aiDisabled: false, chatDisabled: false },
  codes: [],
  notes: [],
  messages: []
};

export async function readDB(): Promise<DB> {
  try {
    const data = await fs.readFile(DB_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if ((error as any).code === 'ENOENT') {
      await writeDB(defaultDB);
      return defaultDB;
    }
    throw error;
  }
}

export async function writeDB(db: DB): Promise<void> {
  await fs.writeFile(DB_PATH, JSON.stringify(db, null, 2));
}

// Ensure storage folders exist
export async function ensureFolders() {
  const folders = ['storage/notes', 'storage/chat'];
  for (const folder of folders) {
    const dir = path.join(process.cwd(), folder);
    try {
      await fs.access(dir);
    } catch {
      await fs.mkdir(dir, { recursive: true });
    }
  }
}
