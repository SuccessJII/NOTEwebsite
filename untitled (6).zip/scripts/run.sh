#!/bin/bash

echo "ALL IN ONE - Web Application Setup"
echo "=================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null
then
    echo "[ERROR] Node.js is not installed. Please install Node.js."
    exit
fi

# Install dependencies if not already done
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build the app
echo "Building the application..."
npm run build

echo ""
echo "How would you like to run the server?"
echo "1. Foreground (Terminal will stay open)"
echo "2. Background (Detached process)"
read -p "Enter choice (1 or 2): " choice

if [ "$choice" == "1" ]; then
    echo "Starting server in Foreground..."
    npm start
elif [ "$choice" == "2" ]; then
    echo "Starting server in Background..."
    nohup npm start > server.log 2>&1 &
    echo "Server is running in the background (PID: $!)."
    echo "Logs are being written to server.log"
else
    echo "Invalid choice."
fi
