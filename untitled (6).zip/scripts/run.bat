@echo off
setlocal

echo ALL IN ONE - Web Application Setup
echo ==================================

:: Check if Node.js is installed
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed. Please install Node.js from https://nodejs.org/
    pause
    exit /b
)

:: Install dependencies if not already done
if not exist "node_modules\" (
    echo Installing dependencies...
    call npm install
)

:: Build the app
echo Building the application...
call npm run build

:: Prompt for run mode
echo.
echo How would you like to run the server?
echo 1. Foreground (Command Prompt will stay open)
echo 2. Background (Hidden window)
set /p choice="Enter choice (1 or 2): "

if "%choice%"=="1" (
    echo Starting server in Foreground...
    call npm start
) else if "%choice%"=="2" (
    echo Starting server in Background...
    :: Create a temporary VBS script to run hidden
    echo Set WshShell = CreateObject("WScript.Shell") > run_hidden.vbs
    echo WshShell.Run "cmd /c npm start > server.log 2>&1", 0, False >> run_hidden.vbs
    cscript //nologo run_hidden.vbs
    del run_hidden.vbs
    echo Server is running in the background. (View server.log for details)
    echo To stop the server, you will need to end the Node.js process via Task Manager.
) else (
    echo Invalid choice.
)

pause
