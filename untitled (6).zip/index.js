// This index.js acts as an entrypoint wrapper for hosting panels (such as Wispbyte/Pterodactyl)
// It spawns the development/TSX server directly to avoid memory-heavy production build errors.
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

console.log('--------------------------------------------------');
console.log('Starting server in lightweight TSX mode...');
console.log('This bypasses the memory-heavy production build step');
console.log('to ensure smooth startup on restricted hosting plans!');
console.log('--------------------------------------------------');

// Spawn tsx to run server.ts directly
const child = spawn('npx', ['tsx', 'server.ts'], {
  stdio: 'inherit',
  cwd: __dirname,
  shell: true,
  env: {
    ...process.env,
    NODE_ENV: 'development' // Run with live dynamic Vite compilation
  }
});

child.on('close', (code) => {
  process.exit(code === null ? 1 : code);
});
