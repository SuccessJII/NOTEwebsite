/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Login from './components/Login';
import AdminLogin from './components/AdminLogin';
import Dashboard from './components/Dashboard';
import AdminDashboard from './components/AdminDashboard';
import StatusCheck from './components/StatusCheck';

export default function App() {
  const [userToken, setUserToken] = useState(localStorage.getItem('user_token'));
  const [adminToken, setAdminToken] = useState(localStorage.getItem('admin_token'));

  // Check user token expiration
  useEffect(() => {
    const expires = localStorage.getItem('user_expires');
    if (userToken && expires && new Date(expires) < new Date()) {
      handleUserLogout();
    }
  }, [userToken]);

  const handleUserLogout = () => {
    localStorage.removeItem('user_token');
    localStorage.removeItem('user_expires');
    setUserToken(null);
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('admin_token');
    setAdminToken(null);
  };

  return (
    <Router>
      <Routes>
        <Route path="/admin" element={
          adminToken ? (
            <StatusCheck isAdminRoute>
              <AdminDashboard token={adminToken} onLogout={handleAdminLogout} />
            </StatusCheck>
          ) : (
            <AdminLogin onLogin={setAdminToken} />
          )
        } />
        
        <Route path="/" element={
          userToken ? (
            <StatusCheck>
              <Dashboard onLogout={handleUserLogout} />
            </StatusCheck>
          ) : (
            <StatusCheck>
              <Login onLogin={setUserToken} />
            </StatusCheck>
          )
        } />
      </Routes>
    </Router>
  );
}

