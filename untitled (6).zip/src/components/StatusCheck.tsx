import React, { useState, useEffect } from 'react';
import { ShieldAlert, Clock } from 'lucide-react';

export default function StatusCheck({ children, isAdminRoute }: { children: React.ReactNode, isAdminRoute?: boolean }) {
  const [status, setStatus] = useState<{ panicMode: boolean, isSchoolTime: boolean } | null>(null);

  useEffect(() => {
    const check = async () => {
      try {
        const res = await fetch('/api/status');
        const data = await res.json();
        setStatus(data);
      } catch (e) {
        console.error(e);
      }
    };
    check();
    const interval = setInterval(check, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  if (!status) return <div className="min-h-screen bg-gray-50 flex items-center justify-center text-gray-500">Loading...</div>;

  // Admin routes bypass panic mode and school time
  if (isAdminRoute) return <>{children}</>;

  if (status.panicMode) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-gray-900 border border-gray-800 rounded-2xl p-8 text-center space-y-4">
          <ShieldAlert className="w-16 h-16 text-red-500 mx-auto animate-pulse" />
          <h1 className="text-3xl font-bold text-white tracking-widest">SYSTEM LOCKDOWN</h1>
          <p className="text-gray-400">The system has been locked by the administrator.</p>
        </div>
      </div>
    );
  }

  if (status.isSchoolTime) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white border border-gray-200 rounded-2xl p-8 text-center shadow-lg space-y-4">
          <Clock className="w-16 h-16 text-blue-500 mx-auto" />
          <h1 className="text-2xl font-bold text-gray-900">Not Available</h1>
          <p className="text-gray-500">
            Access is restricted during school hours. <br/>
            (Monday-Friday: 10 AM to 5 PM Nepali Time)
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
