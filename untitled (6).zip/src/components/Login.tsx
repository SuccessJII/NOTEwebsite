import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';

export default function Login({ onLogin }: { onLogin: (token: string) => void }) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('user_token', data.token);
        if (data.expiresAt) {
          localStorage.setItem('user_expires', data.expiresAt);
        } else {
          localStorage.setItem('user_expires', 'never');
        }
        onLogin(data.token);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Login failed');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-50 p-4">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-2xl shadow-xl border border-slate-100/80">
        <div className="flex flex-col items-center space-y-3">
          <div className="h-16 w-16 bg-gradient-to-tr from-blue-600 to-emerald-500 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg tracking-wider animate-bounce-slow">
            AIO
          </div>
          <div className="text-center">
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight uppercase">AIO Study Hub</h1>
            <p className="text-xs text-slate-500 font-medium mt-1">Enter your unique student access code to enter</p>
          </div>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input 
            type="text" 
            placeholder="ACCESS CODE" 
            value={code} 
            onChange={(e) => setCode(e.target.value)} 
            required 
            className="text-center text-lg font-mono font-bold tracking-widest uppercase h-12 bg-slate-50 border-slate-200 focus:border-blue-500 rounded-xl"
          />
          {error && <p className="text-red-500 text-xs text-center font-semibold bg-red-50 border border-red-100 py-2 rounded-lg">{error}</p>}
          <Button type="submit" className="w-full h-12 text-sm font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-md tracking-wider uppercase">
            Unlock Learning Portal
          </Button>
        </form>
      </div>
    </div>
  );
}
