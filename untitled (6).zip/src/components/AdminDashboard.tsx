import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Trash2, ShieldAlert, ShieldCheck, Plus, Link, FileText, Settings, Key, FilePlus, Search, Download, ExternalLink, FileArchive, FileImage, Film, Music, Copy, Check, Megaphone, Bell, X } from 'lucide-react';

export default function AdminDashboard({ token, onLogout }: { token: string, onLogout: () => void }) {
  const [codes, setCodes] = useState<any[]>([]);
  const [notes, setNotes] = useState<any[]>([]);
  const [panicMode, setPanicMode] = useState(false);
  const [aiDisabled, setAiDisabled] = useState(false);
  const [chatDisabled, setChatDisabled] = useState(false);
  const [onlineCount, setOnlineCount] = useState(0);
  
  // Search and filters
  const [codeSearch, setCodeSearch] = useState('');
  const [noteSearch, setNoteSearch] = useState('');

  // Code form
  const [newCode, setNewCode] = useState('');
  const [codeType, setCodeType] = useState('one_time');
  const [codeValue, setCodeValue] = useState(1);
  const [maxUses, setMaxUses] = useState(1);
  const [sessionDurationType, setSessionDurationType] = useState<'hours' | 'days' | 'never'>('never');
  const [sessionDurationValue, setSessionDurationValue] = useState(24);
  
  // Clipboard copy feedback
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  // Announcement states
  const [announcementText, setAnnouncementText] = useState('');
  const [announcementType, setAnnouncementType] = useState<'info' | 'warning' | 'alert' | 'success'>('info');
  const [activeAnnouncement, setActiveAnnouncement] = useState('');
  const [activeAnnouncementType, setActiveAnnouncementType] = useState<'info' | 'warning' | 'alert' | 'success'>('info');
  const [isFirstLoad, setIsFirstLoad] = useState(true);

  // Note form
  const [noteTitle, setNoteTitle] = useState('');
  const [noteSubject, setNoteSubject] = useState('');
  const [noteType, setNoteType] = useState('link');
  const [noteUrl, setNoteUrl] = useState('');
  const [noteFile, setNoteFile] = useState<File | null>(null);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000); // Dynamic 10s auto-refresh
    return () => clearInterval(interval);
  }, []);

  const headers = { 'Authorization': `Bearer ${token}` };

  const fetchData = async () => {
    try {
      const [codesRes, notesRes, settingsRes] = await Promise.all([
        fetch('/api/admin/codes', { headers }),
        fetch('/api/notes', { headers }),
        fetch('/api/admin/settings', { headers })
      ]);
      
      if (codesRes.status === 401 || notesRes.status === 401 || settingsRes.status === 401) {
        onLogout();
        return;
      }

      const codesData = await codesRes.json();
      const notesData = await notesRes.json();
      setCodes(Array.isArray(codesData) ? codesData : []);
      setNotes(Array.isArray(notesData) ? notesData : []);
      const settings = await settingsRes.json();
      setPanicMode(settings.panicMode || false);
      setAiDisabled(settings.aiDisabled || false);
      setChatDisabled(settings.chatDisabled || false);
      setOnlineCount(settings.onlineCount || 0);
      setActiveAnnouncement(settings.announcement || '');
      setActiveAnnouncementType(settings.announcementType || 'info');
      
      if (isFirstLoad) {
        setAnnouncementText(settings.announcement || '');
        setAnnouncementType(settings.announcementType || 'info');
        setIsFirstLoad(false);
      }
    } catch (e) {
      console.error(e);
      onLogout(); // Safe fallback for expired or invalid token
    }
  };

  const handleCopyCode = (id: string, codeStr: string) => {
    navigator.clipboard.writeText(codeStr);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  const handleRevokeAllCodes = async () => {
    if (!window.confirm("Are you absolutely sure you want to delete ALL access keys and immediately log out all connected students? This action cannot be undone.")) {
      return;
    }
    try {
      const res = await fetch('/api/admin/codes/all', { method: 'DELETE', headers });
      if (res.status === 401) {
        onLogout();
        return;
      }
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleTogglePanic = async () => {
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({ panicMode: !panicMode })
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      setPanicMode(!panicMode);
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleFeature = async (feature: 'ai' | 'chat') => {
    try {
      const isAi = feature === 'ai';
      const body = isAi 
          ? { aiDisabled: !aiDisabled } 
          : { chatDisabled: !chatDisabled };
          
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      if (isAi) {
        setAiDisabled(!aiDisabled);
      } else {
        setChatDisabled(!chatDisabled);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateAnnouncement = async (e: React.FormEvent, isClear = false) => {
    e.preventDefault();
    try {
      const textToBroadcast = isClear ? '' : announcementText;
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          announcement: textToBroadcast,
          announcementType: announcementType
        })
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      const data = await res.json();
      setActiveAnnouncement(data.announcement || '');
      setActiveAnnouncementType(data.announcementType || 'info');
      if (isClear) {
        setAnnouncementText('');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateCode = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const body: any = { code: newCode, type: codeType, value: codeValue };
      if (codeType === 'one_time') {
        body.maxUses = maxUses;
        body.sessionDurationType = sessionDurationType;
        body.sessionDurationValue = sessionDurationValue;
      }
      const res = await fetch('/api/admin/codes', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      setNewCode('');
      setMaxUses(1);
      setSessionDurationType('never');
      setSessionDurationValue(24);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteCode = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/codes/${id}`, { method: 'DELETE', headers });
      if (res.status === 401) {
        onLogout();
        return;
      }
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('title', noteTitle);
    formData.append('subject', noteSubject);
    formData.append('type', noteType);
    if (noteType === 'link') formData.append('url', noteUrl);
    if (noteType === 'file' && noteFile) formData.append('file', noteFile);

    try {
      const res = await fetch('/api/admin/notes', {
        method: 'POST',
        headers,
        body: formData
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      setNoteTitle('');
      setNoteSubject('');
      setNoteUrl('');
      setNoteFile(null);
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteNote = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/notes/${id}`, { method: 'DELETE', headers });
      if (res.status === 401) {
        onLogout();
        return;
      }
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const getFileBadgeColors = (url: string, type: string) => {
    if (type === 'link') return 'bg-indigo-900/40 text-indigo-300 border-indigo-700/60';
    const ext = url ? url.split('.').pop()?.toLowerCase() : '';
    switch (ext) {
      case 'pdf': return 'bg-red-950/40 text-red-300 border-red-900/60';
      case 'doc':
      case 'docx': return 'bg-blue-950/40 text-blue-300 border-blue-900/60';
      case 'xls':
      case 'xlsx': return 'bg-emerald-950/40 text-emerald-300 border-emerald-900/60';
      case 'ppt':
      case 'pptx': return 'bg-orange-950/40 text-orange-300 border-orange-900/60';
      case 'zip':
      case 'rar':
      case '7z': return 'bg-amber-950/40 text-amber-300 border-amber-900/60';
      default: return 'bg-gray-800 text-gray-300 border-gray-700';
    }
  };

  const filteredCodes = codes.filter(c => 
    c.code.toLowerCase().includes(codeSearch.toLowerCase()) || 
    c.type.toLowerCase().includes(codeSearch.toLowerCase())
  );

  const filteredNotes = notes.filter(n => 
    n.title.toLowerCase().includes(noteSearch.toLowerCase()) || 
    n.subject.toLowerCase().includes(noteSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-6 lg:p-8 font-sans">
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8">
        
        {/* HEADER */}
        <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-slate-900 p-5 sm:p-6 rounded-xl border border-slate-800 gap-4 shadow-lg">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-blue-600/10 rounded-lg text-blue-500 border border-blue-500/20">
                <Settings className="w-6 h-6"/>
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight flex flex-col sm:flex-row sm:items-center gap-2">
                  Admin Control Center
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-xs w-fit">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    {onlineCount} Student{onlineCount !== 1 ? 's' : ''} Online
                  </span>
                </h1>
                <p className="text-slate-400 text-xs sm:text-sm mt-0.5">Generate access codes, manage study files, and restrict system access.</p>
              </div>
            </div>
          </div>
          <div className="flex gap-3 w-full sm:w-auto justify-end">
            <Button onClick={onLogout} variant="ghost" className="text-slate-400 hover:text-white hover:bg-slate-800 h-10 px-4">Logout</Button>
          </div>
        </header>

        {/* PANIC MODE CRISP STATUS PANEL - EXTREMELY HIGH VISIBILITY */}
        {panicMode ? (
          <div className="bg-red-950/40 border-2 border-red-500 text-red-100 p-5 rounded-xl shadow-xl shadow-red-950/30 flex flex-col md:flex-row items-center justify-between gap-5 animate-pulse relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-3xl" />
            <div className="flex items-center gap-4">
              <div className="p-3 bg-red-900 rounded-xl text-red-200 border border-red-400/30 shadow-md">
                <ShieldAlert className="w-8 h-8 text-red-400 animate-bounce" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg sm:text-xl font-black text-red-400 tracking-wide uppercase flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500 animate-ping inline-block" />
                  Panic Mode Active (System Locked)
                </h3>
                <p className="text-xs sm:text-sm text-red-200/90 leading-relaxed font-medium">All students are immediately blocked from accessing any study notes, AI helpers, or chat features.</p>
              </div>
            </div>
            <Button 
              onClick={handleTogglePanic} 
              size="lg" 
              className="bg-red-600 hover:bg-red-500 text-white font-black px-6 py-3 rounded-lg shadow-lg border border-red-400 w-full md:w-auto text-sm tracking-wide uppercase flex items-center justify-center gap-2"
            >
              Disable Lockdown
            </Button>
          </div>
        ) : (
          <div className="bg-emerald-950/30 border border-emerald-500/40 text-emerald-100 p-5 rounded-xl shadow-lg flex flex-col md:flex-row items-center justify-between gap-5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl" />
            <div className="flex items-center gap-4">
              <div className="p-3 bg-emerald-900/40 rounded-xl text-emerald-300 border border-emerald-500/20">
                <ShieldCheck className="w-8 h-8 text-emerald-400" />
              </div>
              <div className="space-y-0.5">
                <h3 className="text-lg sm:text-xl font-black text-emerald-400 tracking-wide uppercase flex items-center gap-2">
                  System Running Normally
                </h3>
                <p className="text-xs sm:text-sm text-emerald-200/80 leading-relaxed">Students are allowed to log in and access their study center as long as they have a valid session key.</p>
              </div>
            </div>
            <Button 
              onClick={handleTogglePanic} 
              size="lg" 
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-3 rounded-lg shadow-md border border-emerald-400/50 w-full md:w-auto text-sm uppercase tracking-wide flex items-center justify-center gap-2"
            >
              Enable Panic Lockdown
            </Button>
          </div>
        )}

        {/* FEATURE TOGGLE CONTROL PANEL */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md flex flex-col md:flex-row items-center justify-between gap-5">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-sm font-bold text-slate-200 tracking-wide uppercase flex items-center justify-center md:justify-start gap-2">
              <span className="h-2 w-2 rounded-full bg-blue-500 animate-pulse" />
              Resource & Communication Control
            </h3>
            <p className="text-xs text-slate-400">Toggle individual modules for students. Useful during class sessions, exams, or maintenance windows.</p>
          </div>
          
          <div className="flex flex-col xl:flex-row gap-4 w-full md:w-auto">
            {/* AI Assistant Toggle */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex items-center justify-between gap-6 flex-1 md:w-56">
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-200">AI Study Helper</span>
                <span className={`text-[10px] font-semibold mt-0.5 ${aiDisabled ? 'text-red-400' : 'text-emerald-400'}`}>
                  {aiDisabled ? '❌ Disabled' : '✅ Active'}
                </span>
              </div>
              <Button 
                onClick={() => handleToggleFeature('ai')}
                size="sm"
                className={`text-xs font-bold h-8 px-3 rounded-md transition-colors ${
                  aiDisabled 
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white' 
                    : 'bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/20'
                }`}
              >
                {aiDisabled ? 'Enable' : 'Disable'}
              </Button>
            </div>

            {/* Live Chat Toggle */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex items-center justify-between gap-6 flex-1 md:w-56">
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-200">Live Chatroom</span>
                <span className={`text-[10px] font-semibold mt-0.5 ${chatDisabled ? 'text-red-400' : 'text-emerald-400'}`}>
                  {chatDisabled ? '❌ Disabled' : '✅ Active'}
                </span>
              </div>
              <Button 
                onClick={() => handleToggleFeature('chat')}
                size="sm"
                className={`text-xs font-bold h-8 px-3 rounded-md transition-colors ${
                  chatDisabled 
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white' 
                    : 'bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/20'
                }`}
              >
                {chatDisabled ? 'Enable' : 'Disable'}
              </Button>
            </div>

            {/* Clear All Sessions / Keys Button */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex items-center justify-between gap-6 flex-1 md:w-56">
              <div className="flex flex-col">
                <span className="text-xs font-bold text-red-400">Force Global Logout</span>
                <span className="text-[10px] font-semibold mt-0.5 text-slate-500">
                  Revokes all active keys
                </span>
              </div>
              <Button 
                onClick={handleRevokeAllCodes}
                size="sm"
                className="bg-red-600/20 hover:bg-red-600/35 text-red-400 border border-red-500/20 text-xs font-bold h-8 px-3 rounded-md transition-colors"
              >
                Revoke All
              </Button>
            </div>
          </div>
        </div>

        {/* GLOBAL BROADCAST SYSTEM */}
        <div className="bg-slate-900 border border-slate-800 p-5 sm:p-6 rounded-xl shadow-md space-y-4">
          <div className="border-b border-slate-800 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-base sm:text-lg font-bold flex items-center gap-2 text-slate-100 uppercase tracking-wide">
                <span className="h-2 w-2 rounded-full bg-blue-500 animate-pulse" />
                Global Student Broadcast System
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Broadcast custom banner messages with live, real-time sync to all logged-in students.</p>
            </div>
            
            {activeAnnouncement ? (
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase border shadow-xs ${
                activeAnnouncementType === 'warning' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                activeAnnouncementType === 'alert' ? 'bg-red-500/10 text-red-400 border-red-500/20 animate-pulse' :
                activeAnnouncementType === 'success' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                'bg-blue-500/10 text-blue-400 border-blue-500/20'
              }`}>
                ● Active Broadcast
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase bg-slate-950 text-slate-500 border border-slate-800 shadow-xs">
                ○ No Active Broadcast
              </span>
            )}
          </div>

          <form onSubmit={(e) => handleUpdateAnnouncement(e, false)} className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-6 lg:col-span-7 space-y-1">
              <label className="text-[11px] text-slate-400 block font-bold uppercase tracking-wider">Broadcast Message</label>
              <Input 
                value={announcementText}
                onChange={e => setAnnouncementText(e.target.value)}
                placeholder="Type important classroom message or alert here..."
                className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus-visible:ring-blue-500 text-xs sm:text-sm h-11"
                maxLength={250}
              />
            </div>

            <div className="md:col-span-3 lg:col-span-2 space-y-1">
              <label className="text-[11px] text-slate-400 block font-bold uppercase tracking-wider">Banner Priority</label>
              <select 
                value={announcementType}
                onChange={e => setAnnouncementType(e.target.value as any)}
                className="bg-slate-950 border-slate-800 rounded-md p-2 text-xs sm:text-sm text-white outline-none w-full border h-11 text-slate-300"
              >
                <option value="info">Info (Blue)</option>
                <option value="warning">Warning (Amber)</option>
                <option value="alert">Alert (Crimson Red)</option>
                <option value="success">Success (Emerald Green)</option>
              </select>
            </div>

            <div className="md:col-span-3 lg:col-span-3 flex items-end gap-2 h-11 md:h-auto">
              <Button 
                type="submit" 
                disabled={!announcementText.trim()}
                className="flex-1 h-11 bg-blue-600 hover:bg-blue-500 text-white font-bold gap-1.5 text-xs sm:text-sm shadow-md"
              >
                Broadcast
              </Button>
              {activeAnnouncement && (
                <Button 
                  type="button" 
                  onClick={(e) => handleUpdateAnnouncement(e, true)}
                  className="px-3 h-11 bg-red-600/10 hover:bg-red-600/20 text-red-400 border border-red-500/20 font-semibold text-xs rounded-md"
                  title="Clear active broadcast"
                >
                  Clear
                </Button>
              )}
            </div>
          </form>

          {activeAnnouncement && (
            <div className="mt-3 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80 flex items-center gap-3">
              <span className="text-[10px] font-black tracking-wider uppercase px-2 py-0.5 rounded-sm bg-slate-800 text-slate-400">Live Preview</span>
              <p className={`text-xs font-semibold ${
                activeAnnouncementType === 'warning' ? 'text-amber-400' :
                activeAnnouncementType === 'alert' ? 'text-red-400 animate-pulse' :
                activeAnnouncementType === 'success' ? 'text-emerald-400' :
                'text-blue-400'
              }`}>
                "{activeAnnouncement}"
              </p>
            </div>
          )}
        </div>

        {/* TWO-COLUMN MANAGEMENT PANELS */}
        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8">
          
          {/* ACCESS CODES SECTION */}
          <section className="bg-slate-900 p-5 sm:p-6 rounded-xl border border-slate-800 space-y-6 shadow-md flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2 text-slate-100">
                  <Key className="w-5 h-5 text-blue-500"/> 
                  Access Keys ({codes.length})
                </h2>
                
                {/* Micro Search Bar for Codes */}
                <div className="relative max-w-[160px] sm:max-w-[200px]">
                  <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
                  <Input 
                    placeholder="Search keys..." 
                    value={codeSearch}
                    onChange={e => setCodeSearch(e.target.value)}
                    className="pl-8 h-7 text-xs bg-slate-950 border-slate-800 text-white rounded-md"
                  />
                </div>
              </div>
              
              <form onSubmit={handleCreateCode} className="space-y-4 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="flex gap-2">
                  <Input 
                    placeholder="Code (e.g., MIDTERM24)" 
                    value={newCode} 
                    onChange={e => setNewCode(e.target.value)} 
                    required 
                    className="bg-slate-900 border-slate-800 text-white" 
                  />
                  <Button 
                    type="button" 
                    onClick={() => setNewCode(Math.random().toString(36).substring(2, 8).toUpperCase())} 
                    variant="secondary"
                    className="bg-slate-800 hover:bg-slate-700 h-10 px-4 text-xs font-semibold whitespace-nowrap"
                  >
                    Random
                  </Button>
                </div>
                
                <div className="space-y-3">
                  <label className="text-xs text-slate-400 block font-bold uppercase tracking-wider">Session Key Expiry Rule</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <select 
                      value={codeType} 
                      onChange={e => {
                        setCodeType(e.target.value);
                        if (e.target.value === 'hours') setCodeValue(24);
                        else if (e.target.value === 'days') setCodeValue(7);
                      }} 
                      className="bg-slate-900 border-slate-800 rounded-md p-2 text-xs sm:text-sm text-white outline-none w-full border"
                    >
                      <option value="one_time">One-Time / Limited-Use</option>
                      <option value="hours">Expires after X Hours (Multi-use)</option>
                      <option value="days">Expires after X Days (Multi-use)</option>
                      <option value="never">Never Expires (Unlimited)</option>
                    </select>
                    
                    {(codeType === 'hours' || codeType === 'days') && (
                      <Input 
                        type="number" 
                        min={1} 
                        value={codeValue} 
                        onChange={e => setCodeValue(Number(e.target.value))} 
                        placeholder={codeType === 'hours' ? "Hours (e.g., 24)" : "Days (e.g., 7)"}
                        className="bg-slate-900 border-slate-800 text-white h-10" 
                      />
                    )}
                  </div>

                  {codeType === 'one_time' && (
                    <div className="space-y-3 border-t border-slate-900 pt-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400 block font-bold uppercase tracking-wider">User Usage Limit</label>
                          <Input 
                            type="number" 
                            min={1} 
                            value={maxUses} 
                            onChange={e => setMaxUses(Number(e.target.value))} 
                            placeholder="Max unique logins (e.g., 1 or 4)"
                            className="bg-slate-900 border-slate-800 text-white h-10 text-xs" 
                          />
                        </div>
                        
                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400 block font-bold uppercase tracking-wider">Session Expiration</label>
                          <select 
                            value={sessionDurationType} 
                            onChange={e => {
                              setSessionDurationType(e.target.value as any);
                              if (e.target.value === 'hours') setSessionDurationValue(48); // default to 48 hours!
                              else if (e.target.value === 'days') setSessionDurationValue(2);
                            }} 
                            className="bg-slate-900 border-slate-800 rounded-md p-2 text-xs sm:text-sm text-white outline-none w-full border h-10"
                          >
                            <option value="never">Never Expires (Unlimited)</option>
                            <option value="hours">Expires in X Hours</option>
                            <option value="days">Expires in X Days</option>
                          </select>
                        </div>
                      </div>

                      {(sessionDurationType === 'hours' || sessionDurationType === 'days') && (
                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400 block font-bold uppercase tracking-wider">Duration Value</label>
                          <Input 
                            type="number" 
                            min={1} 
                            value={sessionDurationValue} 
                            onChange={e => setSessionDurationValue(Number(e.target.value))} 
                            placeholder={sessionDurationType === 'hours' ? "Hours (e.g., 48)" : "Days (e.g., 2)"}
                            className="bg-slate-900 border-slate-800 text-white h-10 text-xs" 
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>
                
                <Button type="submit" className="w-full h-10 bg-blue-600 hover:bg-blue-500 text-white font-bold gap-2 text-xs sm:text-sm shadow-md">
                  <Plus className="w-4 h-4"/> Generate Key
                </Button>
              </form>
            </div>

            <div className="space-y-2 max-h-80 overflow-y-auto pr-1 mt-6 border-t border-slate-800 pt-4">
              {filteredCodes.map(c => (
                <div key={c.id} className="flex items-center justify-between bg-slate-950 p-3 rounded-lg border border-slate-800 hover:border-slate-700 transition-colors">
                  <div className="flex-1 min-w-0 pr-3">
                    <div className="font-mono text-blue-400 font-black text-sm tracking-wider uppercase flex items-center gap-2">
                      {c.code}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 font-semibold space-y-0.5">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="capitalize px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-bold text-[9px] leading-none">
                          {c.type === 'one_time' ? (c.maxUses && c.maxUses > 1 ? 'Limited-Use' : 'One-Time') : c.type.replace('_', ' ')}
                        </span>
                        {c.type === 'one_time' && (
                          <span className="text-slate-400 text-[10px]">
                            • Uses: <strong className="text-blue-400">{c.usedBy?.length || 0}</strong> / <strong className="text-slate-300">{c.maxUses || 1}</strong>
                          </span>
                        )}
                        {c.type === 'one_time' && (
                          <span className="text-slate-400 text-[10px]">
                            • Session: <strong className="text-emerald-400">{c.sessionDurationType === 'never' || !c.sessionDurationType ? 'Never expires' : `${c.sessionDurationValue} ${c.sessionDurationType}`}</strong>
                          </span>
                        )}
                        {(c.type === 'hours' || c.type === 'days') && (
                          <span className="text-slate-400 text-[10px]">
                            • Duration: <strong className="text-emerald-400">{c.value} {c.type}</strong>
                          </span>
                        )}
                        {c.expiresAt && (
                          <span className="text-amber-400 text-[10px] font-medium">
                            • Key Exp: {new Date(c.expiresAt).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className={`h-8 w-8 rounded-lg ${copiedCodeId === c.id ? 'text-emerald-400' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`} 
                      onClick={() => handleCopyCode(c.id, c.code)}
                      title="Copy access key"
                    >
                      {copiedCodeId === c.id ? (
                        <Check className="w-4 h-4 text-emerald-400 animate-pulse" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      className="text-red-400 hover:text-red-300 hover:bg-red-950/50 h-8 w-8 rounded-lg" 
                      onClick={() => handleDeleteCode(c.id)}
                      title="Delete key"
                    >
                      <Trash2 className="w-4 h-4"/>
                    </Button>
                  </div>
                </div>
              ))}
              {filteredCodes.length === 0 && (
                <p className="text-slate-500 text-xs py-8 text-center font-medium">No matching access keys found.</p>
              )}
            </div>
          </section>

          {/* NOTES MANAGEMENT SECTION */}
          <section className="bg-slate-900 p-5 sm:p-6 rounded-xl border border-slate-800 space-y-6 shadow-md flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h2 className="text-lg sm:text-xl font-bold flex items-center gap-2 text-slate-100">
                  <FilePlus className="w-5 h-5 text-emerald-500"/> 
                  Upload Notes ({notes.length})
                </h2>
                
                {/* Micro Search Bar for Notes */}
                <div className="relative max-w-[160px] sm:max-w-[200px]">
                  <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
                  <Input 
                    placeholder="Search notes..." 
                    value={noteSearch}
                    onChange={e => setNoteSearch(e.target.value)}
                    className="pl-8 h-7 text-xs bg-slate-950 border-slate-800 text-white rounded-md"
                  />
                </div>
              </div>
              
              <form onSubmit={handleCreateNote} className="space-y-4 bg-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <Input placeholder="Note Title" value={noteTitle} onChange={e => setNoteTitle(e.target.value)} required className="bg-slate-900 border-slate-800 text-white" />
                  <Input placeholder="Subject (e.g., MATH)" value={noteSubject} onChange={e => setNoteSubject(e.target.value)} required className="bg-slate-900 border-slate-800 text-white" />
                </div>
                
                <div className="flex gap-4 border-b border-slate-800 pb-2.5">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input type="radio" checked={noteType === 'link'} onChange={() => setNoteType('link')} className="accent-blue-500 h-4 w-4"/>
                    <span className="text-xs font-semibold">Drive Link</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input type="radio" checked={noteType === 'file'} onChange={() => setNoteType('file')} className="accent-blue-500 h-4 w-4"/>
                    <span className="text-xs font-semibold">Upload Any File</span>
                  </label>
                </div>

                {noteType === 'link' ? (
                  <Input placeholder="Google Drive URL" value={noteUrl} onChange={e => setNoteUrl(e.target.value)} required className="bg-slate-900 border-slate-800 text-white" />
                ) : (
                  <div className="border border-slate-800 rounded-lg p-2 bg-slate-900/50 flex items-center">
                    <input 
                      type="file" 
                      onChange={e => setNoteFile(e.target.files?.[0] || null)} 
                      required 
                      className="w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-[11px] file:font-bold file:bg-emerald-600 file:text-white hover:file:bg-emerald-500 cursor-pointer" 
                    />
                  </div>
                )}
                
                <Button type="submit" className="w-full h-10 bg-emerald-600 hover:bg-emerald-500 text-white font-bold gap-2 text-xs sm:text-sm shadow-md">
                  <Plus className="w-4 h-4"/> Add Note Item
                </Button>
              </form>
            </div>

            <div className="space-y-2 max-h-80 overflow-y-auto pr-1 mt-6 border-t border-slate-800 pt-4">
              {filteredNotes.map(n => {
                const isLink = n.type === 'link';
                return (
                  <div key={n.id} className="flex items-center justify-between bg-slate-950 p-3 rounded-lg border border-slate-800 hover:border-slate-700 transition-colors">
                    <div className="flex-1 overflow-hidden pr-2">
                      <div className="font-semibold text-sm text-slate-200 truncate">{n.title}</div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-1 font-bold">
                        <span className="uppercase">{n.subject}</span>
                        <span>•</span>
                        <span className={`px-1.5 py-0.5 rounded border text-[9px] font-extrabold uppercase ${getFileBadgeColors(n.url, n.type)}`}>
                          {isLink ? 'Drive Link' : (n.url ? n.url.split('.').pop() : 'File')}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-1.5">
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        onClick={() => window.open(n.url, '_blank')}
                        className="text-slate-400 hover:text-white hover:bg-slate-800 h-8 w-8 rounded-lg"
                        title="View File"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </Button>
                      <Button 
                        size="icon" 
                        variant="ghost" 
                        className="text-red-400 hover:text-red-300 hover:bg-red-950/50 h-8 w-8 rounded-lg" 
                        onClick={() => handleDeleteNote(n.id)}
                        title="Delete File"
                      >
                        <Trash2 className="w-4 h-4"/>
                      </Button>
                    </div>
                  </div>
                );
              })}
              {filteredNotes.length === 0 && (
                <p className="text-slate-500 text-xs py-8 text-center font-medium">No matching notes found.</p>
              )}
            </div>
          </section>

        </div>
      </div>
    </div>
  );
}
