import express from 'express';
import path from 'path';
import cors from 'cors';
import multer from 'multer';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { readDB, writeDB, ensureFolders, Code, Note, ChatMessage } from './server/db.js';
import { v4 as uuidv4 } from 'uuid';
import { GoogleGenAI } from '@google/genai';
import { toZonedTime, format } from 'date-fns-tz';
import fs from 'fs';
import crypto from 'crypto';

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*' }
});

app.use(cors());
app.use(express.json());

const SESSION_SECRET = 'highly_secure_session_secret_12837';
const activeSockets = new Map<string, string>(); // socket.id -> code

function createToken(code: string, expiresAt?: string): string {
  const payload = `${code}:${expiresAt || 'never'}`;
  const signature = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');
  return `user_token_${code}_${expiresAt || 'never'}_${signature}`;
}

function verifyToken(token: string): { valid: boolean; code?: string; expiresAt?: string } {
  if (!token || !token.startsWith('user_token_')) {
    return { valid: false };
  }
  const parts = token.slice('user_token_'.length).split('_');
  if (parts.length !== 3) {
    return { valid: false };
  }
  const [code, expiresAt, signature] = parts;
  const payload = `${code}:${expiresAt}`;
  const expectedSignature = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');
  if (signature !== expectedSignature) {
    return { valid: false };
  }
  
  if (expiresAt !== 'never') {
    const expDate = new Date(expiresAt);
    if (isNaN(expDate.getTime()) || expDate < new Date()) {
      return { valid: false };
    }
  }
  return { valid: true, code, expiresAt: expiresAt === 'never' ? undefined : expiresAt };
}

const userAuth = async (req: any, res: any, next: any) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const token = authHeader.split(' ')[1];
  if (token === 'admin_token_secret') {
    next();
    return;
  }
  const { valid, code } = verifyToken(token);
  if (!valid || !code) {
    return res.status(401).json({ error: 'Session expired or invalid' });
  }
  const db = await readDB();
  const exists = db.codes.some(c => c.code.toLowerCase() === code.toLowerCase());
  if (!exists) {
    return res.status(401).json({ error: 'Your access code has been deleted or revoked' });
  }
  req.userCode = code;
  next();
};

// Set up Multer for Notes and Chat uploads
const notesStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(process.cwd(), 'storage/notes')),
  filename: (req, file, cb) => cb(null, `${uuidv4()}-${file.originalname}`)
});
const chatStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(process.cwd(), 'storage/chat')),
  filename: (req, file, cb) => cb(null, `${uuidv4()}-${file.originalname}`)
});
const uploadNotes = multer({ storage: notesStorage, limits: { fileSize: 150 * 1024 * 1024 } });
const uploadChat = multer({ storage: chatStorage, limits: { fileSize: 150 * 1024 * 1024 } });

// Serve storage folders
app.use('/storage', express.static(path.join(process.cwd(), 'storage')));

// --- Middlewares ---
// Admin auth middleware (simple hardcoded as requested)
const adminAuth = (req: any, res: any, next: any) => {
  const { email, password } = req.body; // or headers
  const authHeader = req.headers.authorization;
  if (authHeader === 'Bearer admin_token_secret' || (email === 'unknown@admin.com' && password === 'cantfindme0912')) {
    next();
  } else {
    res.status(401).json({ error: 'Unauthorized' });
  }
};

// Check time restriction (Nepali time 10 AM to 5 PM, Mon-Fri)
app.get('/api/status', async (req, res) => {
  const db = await readDB();
  const timeZone = 'Asia/Kathmandu';
  const now = new Date();
  
  const dayStr = format(now, 'i', { timeZone }); // 1=Monday, 7=Sunday
  const hourStr = format(now, 'H', { timeZone }); // 0-23
  
  const day = parseInt(dayStr, 10);
  const hour = parseInt(hourStr, 10);

  // Mon-Fri (1-5) and 10 AM to 5 PM (10 to 16, i.e. < 17)
  const isSchoolTime = day >= 1 && day <= 5 && hour >= 10 && hour < 17;

  res.json({
    panicMode: db.settings.panicMode,
    aiDisabled: db.settings.aiDisabled || false,
    chatDisabled: db.settings.chatDisabled || false,
    announcement: (db.settings as any).announcement || '',
    announcementType: (db.settings as any).announcementType || 'info',
    isSchoolTime,
    time: format(now, 'yyyy-MM-dd HH:mm:ssXXX', { timeZone })
  });
});

// --- API Routes ---
// Admin Login
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (email === 'unknown@admin.com' && password === 'cantfindme0912') {
    res.json({ token: 'admin_token_secret' });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// Settings
app.post('/api/admin/settings', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const { panicMode, aiDisabled, chatDisabled, announcement, announcementType } = req.body;
  const db = await readDB();
  if (panicMode !== undefined) db.settings.panicMode = panicMode;
  if (aiDisabled !== undefined) db.settings.aiDisabled = aiDisabled;
  if (chatDisabled !== undefined) db.settings.chatDisabled = chatDisabled;
  if (announcement !== undefined) (db.settings as any).announcement = announcement;
  if (announcementType !== undefined) (db.settings as any).announcementType = announcementType;
  await writeDB(db);

  // Broadcast settings change including announcements
  io.emit('settings_updated', {
    panicMode: db.settings.panicMode || false,
    aiDisabled: db.settings.aiDisabled || false,
    chatDisabled: db.settings.chatDisabled || false,
    announcement: (db.settings as any).announcement || '',
    announcementType: (db.settings as any).announcementType || 'info'
  });

  res.json({ success: true, ...db.settings });
});

app.get('/api/admin/settings', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const db = await readDB();
  res.json({
    panicMode: db.settings.panicMode || false,
    aiDisabled: db.settings.aiDisabled || false,
    chatDisabled: db.settings.chatDisabled || false,
    announcement: (db.settings as any).announcement || '',
    announcementType: (db.settings as any).announcementType || 'info',
    onlineCount: new Set(activeSockets.values()).size
  });
});

// Codes
app.get('/api/admin/codes', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const db = await readDB();
  res.json(db.codes);
});

app.post('/api/admin/codes', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const { code, type, value, maxUses, sessionDurationType, sessionDurationValue } = req.body;
  const db = await readDB();
  let expiresAt = undefined;
  if (type === 'days') {
    const d = new Date();
    d.setDate(d.getDate() + value);
    expiresAt = d.toISOString();
  } else if (type === 'hours') {
    const d = new Date();
    d.setHours(d.getHours() + value);
    expiresAt = d.toISOString();
  }

  const newCode: Code = {
    id: uuidv4(),
    code,
    type,
    value,
    createdAt: new Date().toISOString(),
    expiresAt,
    usedBy: []
  };

  if (type === 'one_time') {
    newCode.maxUses = maxUses || 1;
    newCode.sessionDurationType = sessionDurationType || 'never';
    newCode.sessionDurationValue = sessionDurationValue || undefined;
  }

  db.codes.push(newCode);
  await writeDB(db);
  res.json(newCode);
});

app.delete('/api/admin/codes/all', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const db = await readDB();
  
  // Broadcast code revocation to log out everyone using any code
  for (const c of db.codes) {
    io.emit('code_revoked', { code: c.code });
  }

  db.codes = [];
  await writeDB(db);
  res.json({ success: true });
});

app.delete('/api/admin/codes/:id', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const db = await readDB();
  const codeToDelete = db.codes.find(c => c.id === req.params.id);
  if (codeToDelete) {
    // Broadcast revocation of this code to immediately kick out the student
    io.emit('code_revoked', { code: codeToDelete.code });
    db.codes = db.codes.filter(c => c.id !== req.params.id);
    await writeDB(db);
  }
  res.json({ success: true });
});

app.delete('/api/admin/chat', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const db = await readDB();
  
  // Clean up files in storage/chat
  for (const msg of db.messages) {
    if (msg.fileUrl) {
      try {
        fs.unlinkSync(path.join(process.cwd(), msg.fileUrl));
      } catch (e) {}
    }
  }

  db.messages = [];
  await writeDB(db);
  io.emit('init_messages', []); // Notify all clients
  res.json({ success: true });
});

// User Login (Code validation)
app.post('/api/login', async (req, res) => {
  const { code } = req.body;
  const db = await readDB();
  const c = db.codes.find(x => x.code.toLowerCase() === code.toLowerCase());
  
  if (!c) {
    return res.status(401).json({ error: 'Invalid code' });
  }

  // Check expiration of the code itself if it was generated statically
  if (c.expiresAt && new Date(c.expiresAt) < new Date()) {
    return res.status(401).json({ error: 'Code expired' });
  }

  if (c.type === 'one_time') {
    const limit = c.maxUses || 1;
    c.usedBy = c.usedBy || [];
    if (c.usedBy.length >= limit) {
      return res.status(401).json({ error: 'Code usage limit reached' });
    }
    c.usedBy.push('user_' + uuidv4());
    await writeDB(db);
  }

  // Compute session expiration dynamically relative to student login time
  let userExpiresAt: string | undefined = undefined;
  if (c.type === 'hours') {
    const d = new Date();
    d.setHours(d.getHours() + (c.value || 24));
    userExpiresAt = d.toISOString();
  } else if (c.type === 'days') {
    const d = new Date();
    d.setDate(d.getDate() + (c.value || 1));
    userExpiresAt = d.toISOString();
  } else if (c.type === 'one_time' && c.sessionDurationType && c.sessionDurationType !== 'never') {
    const d = new Date();
    if (c.sessionDurationType === 'hours') {
      d.setHours(d.getHours() + (c.sessionDurationValue || 24));
    } else if (c.sessionDurationType === 'days') {
      d.setDate(d.getDate() + (c.sessionDurationValue || 1));
    }
    userExpiresAt = d.toISOString();
  }

  const token = createToken(code, userExpiresAt);
  res.json({ success: true, token, expiresAt: userExpiresAt });
});

// Notes
app.get('/api/notes', userAuth, async (req, res) => {
  const db = await readDB();
  res.json(db.notes);
});

app.post('/api/admin/notes', uploadNotes.single('file'), async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const { title, subject, type, url } = req.body;
  const db = await readDB();
  
  const newNote: Note = {
    id: uuidv4(),
    title,
    subject,
    type,
    createdAt: new Date().toISOString()
  };

  if (type === 'file' && req.file) {
    newNote.filename = req.file.filename;
    newNote.url = `/storage/notes/${req.file.filename}`;
  } else if (type === 'link') {
    newNote.url = url;
  }

  db.notes.push(newNote);
  await writeDB(db);
  res.json(newNote);
});

app.delete('/api/admin/notes/:id', async (req, res) => {
  if (req.headers.authorization !== 'Bearer admin_token_secret') return res.status(401).json({ error: 'Unauthorized' });
  const db = await readDB();
  const note = db.notes.find(n => n.id === req.params.id);
  if (note && note.filename) {
    try {
      fs.unlinkSync(path.join(process.cwd(), 'storage/notes', note.filename));
    } catch (e) {}
  }
  db.notes = db.notes.filter(n => n.id !== req.params.id);
  await writeDB(db);
  res.json({ success: true });
});

app.get('/api/notes/view/:filename', userAuth, async (req: any, res) => {
  io.emit('note_viewed', { code: req.userCode, filename: req.params.filename });
  const filePath = path.join(process.cwd(), 'storage/notes', req.params.filename);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found' });
  
  res.sendFile(filePath);
});

// Chat file upload
app.post('/api/chat/upload', userAuth, uploadChat.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  res.json({ url: `/storage/chat/${req.file.filename}`, fileName: req.file.originalname });
});

// Gemini AI
app.post('/api/ai/ask', userAuth, async (req, res) => {
  const db = await readDB();
  if (db.settings.aiDisabled) {
    return res.status(403).json({ error: 'AI Study Helper has been temporarily disabled by the administrator.' });
  }
  const { prompt } = req.body;
  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
  }
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    res.json({ text: response.text });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// --- Socket.io Chat ---
io.use(async (socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) {
    return next(new Error('Authentication error'));
  }
  if (token === 'admin_token_secret') {
    return next();
  }
  const { valid, code } = verifyToken(token);
  if (!valid || !code) {
    return next(new Error('Session expired or invalid'));
  }
  const db = await readDB();
  const exists = db.codes.some(c => c.code.toLowerCase() === code.toLowerCase());
  if (!exists) {
    return next(new Error('Your access code has been deleted or revoked'));
  }
  next();
});

io.on('connection', async (socket) => {
  const token = socket.handshake.auth.token;
  if (token && token !== 'admin_token_secret') {
    const { valid, code } = verifyToken(token);
    if (valid && code) {
      activeSockets.set(socket.id, code);
    }
  }

  socket.on('disconnect', () => {
    activeSockets.delete(socket.id);
  });

  const db = await readDB();
  socket.emit('init_messages', db.messages.slice(-100)); // send last 100

  socket.on('send_message', async (data) => {
    const currentDb = await readDB();
    if (currentDb.settings.chatDisabled) {
      return; // Chat is disabled, do not process
    }
    const newMsg: ChatMessage = {
      id: uuidv4(),
      username: data.username,
      text: data.text,
      fileUrl: data.fileUrl,
      fileName: data.fileName,
      createdAt: new Date().toISOString()
    };
    currentDb.messages.push(newMsg);
    // keep only last 500
    if (currentDb.messages.length > 500) {
      const removed = currentDb.messages.shift();
      if (removed && removed.fileUrl) {
        try {
          fs.unlinkSync(path.join(process.cwd(), removed.fileUrl));
        } catch (e) {}
      }
    }
    await writeDB(currentDb);
    io.emit('new_message', newMsg);
  });

  socket.on('delete_message', async (data) => {
    const currentDb = await readDB();
    const msgIndex = currentDb.messages.findIndex(m => m.id === data.id);
    if (msgIndex !== -1) {
      const msg = currentDb.messages[msgIndex];
      // Allow sender or admin to delete
      if (msg.username === data.username || data.username === 'Admin') {
        msg.isDeleted = true;
        msg.text = `${msg.username} deleted the message`;
        if (msg.fileUrl) {
          try {
            fs.unlinkSync(path.join(process.cwd(), msg.fileUrl));
          } catch (e) {}
          msg.fileUrl = undefined;
          msg.fileName = undefined;
        }
        await writeDB(currentDb);
        io.emit('message_deleted', { id: data.id });
      }
    }
  });
});

async function startServer() {
  await ensureFolders();
  
  const isProduction = 
    process.env.NODE_ENV === 'production' || 
    (typeof __filename !== 'undefined' && (__filename.endsWith('.cjs') || __filename.includes('dist'))) ||
    !fs.existsSync(path.join(process.cwd(), 'server.ts'));

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
