import fs from 'fs';
import path from 'path';

async function migrate() {
  const dbPath = path.join(process.cwd(), 'db.json');
  const db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
  
  const src = path.join(process.cwd(), 'storage/notes');
  const dest = path.join(process.cwd(), 'private_storage/notes');
  
  if (fs.existsSync(src)) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    
    for (const note of db.notes) {
      if (note.type === 'file' && note.filename) {
        const oldPath = path.join(src, note.filename);
        const newPath = path.join(dest, note.filename);
        if (fs.existsSync(oldPath)) {
          fs.renameSync(oldPath, newPath);
        }
        note.url = `/api/notes/view/${note.filename}`;
      }
    }
  }
  
  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
  console.log('Migration complete');
}

migrate();
