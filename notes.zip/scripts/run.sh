#!/bin/bash

echo "ALL IN ONE - Web Application Setup"
echo "=================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null
then
    echo "[ERROR] Node.js is not installed. Please install Node.js."
    exit
fi

# Install dependencies if not already done
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build the app
echo "Building the application..."
npm run build

echo ""
echo "How would you like to run the server?"
echo "1. Foreground (Terminal will stay open)"
echo "2. Background (Detached process)"
read -p "Enter choice (1 or 2): " choice

if [ "$choice" == "1" ]; then
    echo "Starting server in Foreground..."
    npm start
elif [ "$choice" == "2" ]; then
    echo "Starting server in Background..."
    # Set default port to 3000 if not specified
    export PORT=${PORT:-3000}
    nohup node dist/server.cjs > server.log 2>&1 &
    SERVER_PID=$!
    echo "Server is running in the background (PID: $SERVER_PID)."
    echo "Logs are being written to server.log"
    echo ""
    echo "=================================="
    echo "Application is now online!"
    echo "You can access it at: http://<your-vps-ip>:$PORT"
    echo "To view live logs: tail -f server.log"
    echo "To stop the server: kill $SERVER_PID"
    echo "=================================="
else
    echo "Invalid choice."
fi
