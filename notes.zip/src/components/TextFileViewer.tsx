import React from 'react';
import { X } from 'lucide-react';

export default function TextFileViewer({ content, fileName, onClose }: { content: string; fileName: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[85vh] flex flex-col">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="font-bold text-slate-900">{fileName}</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-900">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 overflow-y-auto flex-1 bg-slate-50">
          <pre className="whitespace-pre-wrap break-words font-mono text-sm text-slate-700 leading-relaxed">
            {content}
          </pre>
        </div>
      </div>
    </div>
  );
}
