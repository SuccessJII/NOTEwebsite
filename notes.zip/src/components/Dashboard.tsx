import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { FileText, Link as LinkIcon, MessageSquare, Bot, LogOut, Download, Send, Paperclip, Search, Clock, ExternalLink, FileArchive, FileImage, FileCode, Film, Music, Trash2, Megaphone, AlertTriangle, Info, X, Sparkles, ShieldCheck } from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import ReactMarkdown from 'react-markdown';
import TextFileViewer from './TextFileViewer';

export default function Dashboard({ onLogout }: { onLogout: () => void }) {
  const [activeTab, setActiveTab] = useState<'notes' | 'chat' | 'ai'>('notes');
  const [viewingFile, setViewingFile] = useState<{ content: string; name: string } | null>(null);
  
  // Notes
  const [notes, setNotes] = useState<any[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Chat
  const [messages, setMessages] = useState<any[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [username, setUsername] = useState(localStorage.getItem('chat_username') || '');
  const [socket, setSocket] = useState<Socket | null>(null);
  
  // AI
  const [aiInput, setAiInput] = useState('');
  const [aiHistory, setAiHistory] = useState<{role: 'user'|'ai', text: string}[]>([]);
  const [aiLoading, setAiLoading] = useState(false);

  // Session timer
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  // Feature Toggles from status
  const [aiDisabled, setAiDisabled] = useState(false);
  const [chatDisabled, setChatDisabled] = useState(false);

  // Broadcast Announcement Banner states
  const [announcement, setAnnouncement] = useState<string>('');
  const [announcementType, setAnnouncementType] = useState<'info' | 'warning' | 'alert' | 'success'>('info');
  const [dismissedAnnouncement, setDismissedAnnouncement] = useState<string>('');

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/status');
        const data = await res.json();
        setAiDisabled(data.aiDisabled || false);
        setChatDisabled(data.chatDisabled || false);
        setAnnouncement(data.announcement || '');
        setAnnouncementType(data.announcementType || 'info');
      } catch (err) {
        console.error('Failed to fetch status:', err);
      }
    };
    fetchStatus();
    const interval = setInterval(fetchStatus, 15000); // Check every 15s
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('user_token') || '';
    const headers = { 'Authorization': `Bearer ${token}` };

    const checkResponse = async (res: Response) => {
      if (res.status === 401) {
        onLogout();
        throw new Error('Unauthorized');
      }
      return res.json();
    };

    fetch('/api/notes', { headers })
      .then(checkResponse)
      .then(data => setNotes(Array.isArray(data) ? data : []))
      .catch(err => {
        console.error('Failed to fetch notes:', err);
        setNotes([]);
      });

    const newSocket = io({
      auth: { token }
    });
    setSocket(newSocket);

    newSocket.on('init_messages', (msgs: any[]) => setMessages(msgs));
    newSocket.on('new_message', (msg: any) => setMessages(prev => [...prev, msg]));
    newSocket.on('message_deleted', (data: { id: string }) => {
      setMessages(prev => prev.map(m => m.id === data.id ? { ...m, isDeleted: true, text: `${m.username} deleted the message`, fileUrl: undefined, fileName: undefined } : m));
    });
    newSocket.on('code_revoked', (data: { code: string }) => {
      const getCodeFromToken = (tok: string) => {
        if (!tok || !tok.startsWith('user_token_')) return '';
        const parts = tok.slice('user_token_'.length).split('_');
        return parts[0] || '';
      };
      const myCode = getCodeFromToken(token);
      if (myCode && data.code && myCode.toLowerCase() === data.code.toLowerCase()) {
        onLogout();
      }
    });

    newSocket.on('settings_updated', (data: { aiDisabled?: boolean; chatDisabled?: boolean; announcement?: string; announcementType?: 'info' | 'warning' | 'alert' | 'success' }) => {
      if (data.aiDisabled !== undefined) setAiDisabled(data.aiDisabled);
      if (data.chatDisabled !== undefined) setChatDisabled(data.chatDisabled);
      if (data.announcement !== undefined) setAnnouncement(data.announcement);
      if (data.announcementType !== undefined) setAnnouncementType(data.announcementType);
    });

    // Session Timer logic
    const expires = localStorage.getItem('user_expires');
    if (expires && expires !== 'never') {
      const updateTimer = () => {
        const diff = new Date(expires).getTime() - Date.now();
        if (diff <= 0) {
          onLogout();
          return;
        }
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);
        
        let display = '';
        if (hours > 0) display += `${hours}h `;
        display += `${mins}m ${secs}s`;
        setTimeRemaining(display);
      };
      updateTimer();
      const interval = setInterval(updateTimer, 1000);
      return () => {
        clearInterval(interval);
        newSocket.disconnect();
      };
    } else {
      setTimeRemaining('Unlimited Session');
    }

    return () => { newSocket.disconnect(); };
  }, [onLogout]);

  const subjects = ['All', ...Array.from(new Set(notes.map(n => n.subject)))];
  
  const filteredNotes = notes.filter(n => {
    const matchesSubject = selectedSubject === 'All' || n.subject === selectedSubject;
    const matchesSearch = n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          n.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  const getFileBadge = (url: string, type: string) => {
    if (type === 'link') {
      return { 
        label: 'Google Drive', 
        bg: 'bg-indigo-50 text-indigo-700 border-indigo-200', 
        icon: <LinkIcon className="w-3.5 h-3.5 text-indigo-500" /> 
      };
    }
    const ext = url ? url.split('.').pop()?.toLowerCase() : '';
    switch (ext) {
      case 'pdf':
        return { 
          label: 'PDF Doc', 
          bg: 'bg-red-50 text-red-700 border-red-200', 
          icon: <FileText className="w-3.5 h-3.5 text-red-500" /> 
        };
      case 'doc':
      case 'docx':
        return { 
          label: 'Word Doc', 
          bg: 'bg-blue-50 text-blue-700 border-blue-200', 
          icon: <FileText className="w-3.5 h-3.5 text-blue-500" /> 
        };
      case 'xls':
      case 'xlsx':
        return { 
          label: 'Excel Sheet', 
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', 
          icon: <FileText className="w-3.5 h-3.5 text-emerald-500" /> 
        };
      case 'ppt':
      case 'pptx':
        return { 
          label: 'PowerPoint', 
          bg: 'bg-orange-50 text-orange-700 border-orange-200', 
          icon: <FileText className="w-3.5 h-3.5 text-orange-500" /> 
        };
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'webp':
      case 'gif':
        return { 
          label: 'Image', 
          bg: 'bg-purple-50 text-purple-700 border-purple-200', 
          icon: <FileImage className="w-3.5 h-3.5 text-purple-500" /> 
        };
      case 'zip':
      case 'rar':
      case '7z':
        return { 
          label: 'Archive', 
          bg: 'bg-amber-50 text-amber-700 border-amber-200', 
          icon: <FileArchive className="w-3.5 h-3.5 text-amber-600" /> 
        };
      case 'mp4':
      case 'mkv':
      case 'avi':
      case 'mov':
        return {
          label: 'Video',
          bg: 'bg-pink-50 text-pink-700 border-pink-200',
          icon: <Film className="w-3.5 h-3.5 text-pink-500" />
        };
      case 'mp3':
      case 'wav':
      case 'aac':
        return {
          label: 'Audio',
          bg: 'bg-teal-50 text-teal-700 border-teal-200',
          icon: <Music className="w-3.5 h-3.5 text-teal-500" />
        };
      default:
        return { 
          label: ext ? `${ext.toUpperCase()} File` : 'Document', 
          bg: 'bg-gray-50 text-gray-700 border-gray-200', 
          icon: <FileText className="w-3.5 h-3.5 text-gray-500" /> 
        };
    }
  };

  const isImageFile = (fileName?: string) => {
    if (!fileName) return false;
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'].includes(ext);
  };

  const isVideoFile = (fileName?: string) => {
    if (!fileName) return false;
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    return ['mp4', 'webm', 'ogg', 'mov', 'mkv', 'avi'].includes(ext);
  };

  const handleDeleteMessage = (id: string) => {
    socket?.emit('delete_message', { id, username });
  };

  const handleChatSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username) {
      alert("Please set a username first.");
      return;
    }
    if (!chatInput.trim()) return;
    
    socket?.emit('send_message', { username, text: chatInput });
    setChatInput('');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!username) {
      alert("Please set a username first.");
      e.target.value = '';
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 150 * 1024 * 1024) {
      alert("File too large. Limit 150MB");
      return;
    }

    const token = localStorage.getItem('user_token') || '';
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const res = await fetch('/api/chat/upload', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      const data = await res.json();
      if (res.ok) {
        socket?.emit('send_message', { username, text: `Shared a file`, fileUrl: data.url, fileName: data.fileName });
      }
    } catch (err) {
      alert("Upload failed");
    }
    e.target.value = '';
  };

  const handleAiSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiInput.trim()) return;
    
    const userPrompt = aiInput;
    setAiInput('');
    setAiHistory(prev => [...prev, { role: 'user', text: userPrompt }]);
    setAiLoading(true);
    
    const token = localStorage.getItem('user_token') || '';
    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ prompt: userPrompt })
      });
      if (res.status === 401) {
        onLogout();
        return;
      }
      const data = await res.json();
      if (res.ok) {
        setAiHistory(prev => [...prev, { role: 'ai', text: data.text }]);
      } else {
        setAiHistory(prev => [...prev, { role: 'ai', text: `Error: ${data.error}` }]);
      }
    } catch (err) {
      setAiHistory(prev => [...prev, { role: 'ai', text: `Failed to connect to AI.` }]);
    }
    setAiLoading(false);
  };

  const getBannerStyles = () => {
    switch (announcementType) {
      case 'warning':
        return {
          bg: 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-500 text-slate-950',
          icon: <AlertTriangle className="w-4 h-4 text-slate-950 animate-bounce" />,
          badge: 'bg-slate-950/15 text-slate-950 border border-slate-950/20',
          badgeText: 'WARNING'
        };
      case 'alert':
        return {
          bg: 'bg-gradient-to-r from-rose-600 via-red-500 to-rose-600 text-white shadow-lg shadow-rose-950/10',
          icon: <Megaphone className="w-4 h-4 text-white animate-pulse" />,
          badge: 'bg-white/20 text-white border border-white/30 font-black animate-pulse',
          badgeText: 'BROADCAST ALERT'
        };
      case 'success':
        return {
          bg: 'bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-600 text-white',
          icon: <ShieldCheck className="w-4 h-4 text-white" />,
          badge: 'bg-white/20 text-white border border-white/30',
          badgeText: 'UPDATE'
        };
      case 'info':
      default:
        return {
          bg: 'bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-600 text-white shadow-sm',
          icon: <Info className="w-4 h-4 text-white" />,
          badge: 'bg-white/15 text-white border border-white/20',
          badgeText: 'ANNOUNCEMENT'
        };
    }
  };

  const banner = getBannerStyles();
  const showBanner = announcement && dismissedAnnouncement !== announcement;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800">
      {showBanner && (
        <div className={`w-full py-2.5 px-4 sm:px-6 flex items-center justify-between gap-4 transition-all duration-300 relative border-b border-white/10 ${banner.bg}`}>
          <div className="flex items-center gap-3 mx-auto text-center text-xs sm:text-sm font-semibold max-w-4xl min-w-0">
            {banner.icon}
            <span className={`text-[10px] sm:text-xs px-2 py-0.5 rounded-full font-bold uppercase leading-none ${banner.badge}`}>
              {banner.badgeText}
            </span>
            <p className="truncate sm:whitespace-normal break-words leading-tight">{announcement}</p>
          </div>
          <button 
            onClick={() => setDismissedAnnouncement(announcement)}
            className="p-1 rounded-full hover:bg-black/10 text-current transition-colors absolute right-4 top-1/2 -translate-y-1/2"
            title="Dismiss announcement"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      <header className="bg-white border-b border-slate-200 px-4 sm:px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4 sticky top-0 z-10 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 bg-gradient-to-tr from-blue-600 to-emerald-500 rounded-xl flex items-center justify-center text-white font-black text-sm shadow-md tracking-wider relative overflow-hidden group">
            <span className="relative z-10 font-black text-white">AIO</span>
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </div>
          <div>
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight uppercase flex items-center gap-1.5">
              AIO <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-50 text-blue-600 border border-blue-100 rounded-full normal-case tracking-normal">Study Hub</span>
            </h1>
            <p className="text-[11px] text-slate-500 font-medium">Student Study Resource Center</p>
          </div>
        </div>

        {/* Dynamic Session Timer */}
        {timeRemaining && (
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold shadow-xs ${
            timeRemaining === 'Unlimited Session' 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
              : 'bg-amber-50 text-amber-700 border-amber-200 animate-pulse'
          }`}>
            <Clock className="w-3.5 h-3.5" />
            <span>Session: {timeRemaining}</span>
          </div>
        )}

        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          {['notes', 'chat', 'ai'].map(tab => (
            <Button 
              key={tab}
              variant={activeTab === tab ? 'default' : 'ghost'} 
              onClick={() => setActiveTab(tab as any)}
              className={`capitalize text-sm h-10 px-4 rounded-lg font-medium transition-all ${
                activeTab === tab 
                  ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {tab === 'notes' && <FileText className="w-4 h-4 mr-2"/>}
              {tab === 'chat' && <MessageSquare className="w-4 h-4 mr-2"/>}
              {tab === 'ai' && <Bot className="w-4 h-4 mr-2"/>}
              {tab}
              {tab === 'ai' && aiDisabled && (
                <span className="ml-1.5 text-[9px] font-black bg-red-100 text-red-600 px-1.5 py-0.5 rounded-md border border-red-200">OFF</span>
              )}
              {tab === 'chat' && chatDisabled && (
                <span className="ml-1.5 text-[9px] font-black bg-red-100 text-red-600 px-1.5 py-0.5 rounded-md border border-red-200">OFF</span>
              )}
            </Button>
          ))}
          <Button variant="outline" onClick={onLogout} className="ml-2 border-slate-200 hover:bg-slate-100 text-slate-600 hover:text-slate-900 h-10 w-10 p-0" title="Logout">
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 flex flex-col">
        
        {/* NOTES TAB */}
        {activeTab === 'notes' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Filter and Search controls */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
                {subjects.map(sub => (
                  <Button 
                    key={sub} 
                    variant={selectedSubject === sub ? 'default' : 'outline'}
                    onClick={() => setSelectedSubject(sub)}
                    className={`rounded-full px-4 h-8 text-xs font-semibold whitespace-nowrap transition-all ${
                      selectedSubject === sub
                        ? 'bg-blue-600 text-white hover:bg-blue-700'
                        : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                    }`}
                  >
                    {sub}
                  </Button>
                ))}
              </div>
              
              <div className="relative w-full md:max-w-xs flex-shrink-0">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="Search notes or subjects..." 
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-9 h-9 border-slate-200 focus-visible:ring-blue-500 rounded-lg text-sm bg-slate-50/50"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredNotes.map(n => {
                const badge = getFileBadge(n.url, n.type);
                return (
                  <div key={n.id} className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden group">
                    <div className="p-5">
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 uppercase tracking-wider">
                          {n.subject}
                        </span>
                        <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold border ${badge.bg}`}>
                          {badge.icon}
                          <span>{badge.label}</span>
                        </div>
                      </div>
                      <h3 className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors line-clamp-2 text-base leading-snug">
                        {n.title}
                      </h3>
                    </div>
                    
                    {/* View Note / Download Note dual options */}
                    <div className="px-5 py-4 bg-slate-50/50 border-t border-slate-100 grid grid-cols-2 gap-2.5">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={async () => {
                          if (n.type === 'file' && n.url.toLowerCase().endsWith('.txt')) {
                            const res = await fetch(n.url);
                            const text = await res.text();
                            setViewingFile({ content: text, name: n.title || 'Note' });
                          } else {
                            window.open(n.url, '_blank');
                          }
                        }}
                        className="text-xs font-semibold flex items-center justify-center gap-1.5 h-9 bg-white border-slate-200 hover:bg-slate-50 text-slate-700 shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        View Note
                      </Button>
                      <Button 
                        size="sm" 
                        variant="default" 
                        onClick={() => {
                          if (n.type === 'link') {
                            let downloadUrl = n.url;
                            if (downloadUrl.includes('drive.google.com')) {
                              const match = downloadUrl.match(/\/d\/([a-zA-Z0-9_-]+)/) || downloadUrl.match(/id=([a-zA-Z0-9_-]+)/);
                              if (match && match[1]) {
                                downloadUrl = `https://drive.google.com/uc?export=download&id=${match[1]}`;
                              }
                            }
                            window.open(downloadUrl, '_blank');
                          } else {
                            const link = document.createElement('a');
                            link.href = n.url;
                            link.setAttribute('download', n.title || 'Note');
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                          }
                        }}
                        className="text-xs font-semibold flex items-center justify-center gap-1.5 h-9 bg-blue-600 hover:bg-blue-700 text-white shadow-2xs"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </Button>
                    </div>
                  </div>
                );
              })}
              {filteredNotes.length === 0 && (
                <div className="col-span-full bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400">
                  <FileText className="w-12 h-12 mb-3 mx-auto opacity-40 text-slate-400" />
                  <p className="text-sm">No notes match your search or category.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* CHAT TAB */}
        {activeTab === 'chat' && (
          <div className="flex flex-col h-[calc(100vh-190px)] min-h-[400px] bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-300 relative">
            {chatDisabled ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4 bg-slate-50/50">
                <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center border border-red-100 text-red-500 animate-pulse">
                  <MessageSquare className="w-8 h-8" />
                </div>
                <div className="space-y-1 max-w-sm">
                  <h3 className="text-lg font-bold text-slate-800">Chatroom Offline</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">The live student chatroom has been temporarily turned off by the school administrator. Please focus on downloading study notes and using offline materials.</p>
                </div>
              </div>
            ) : (
              <>
                {/* Interactive Username Popup Overlay */}
                {!username && (
                  <div className="absolute inset-0 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-4 z-25 animate-in fade-in duration-300">
                    <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl p-6 sm:p-8 max-w-sm w-full text-center space-y-6 animate-in zoom-in-95 duration-200">
                      <div className="mx-auto w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center border border-blue-200/50">
                        <MessageSquare className="w-6 h-6 animate-pulse" />
                      </div>
                      <div className="space-y-1.5">
                        <h3 className="text-lg font-bold text-slate-900">Enter Chatroom Username</h3>
                        <p className="text-xs text-slate-500 leading-relaxed">Choose a friendly display name to join the live session, share files, and study collaboratively with other students.</p>
                      </div>
                      <form onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                        const name = (formData.get('username-input') as string || '').trim();
                        if (name) {
                          setUsername(name);
                          localStorage.setItem('chat_username', name);
                        }
                      }} className="space-y-3">
                        <Input 
                          name="username-input"
                          placeholder="Type your nickname..."
                          required
                          autoFocus
                          maxLength={25}
                          className="h-11 text-center font-bold text-slate-800 border-slate-200 focus-visible:ring-blue-500 focus-visible:border-blue-500 rounded-xl bg-slate-50/50"
                        />
                        <Button type="submit" className="w-full h-11 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md tracking-wide transition-all">
                          Join Discussion
                        </Button>
                      </form>
                    </div>
                  </div>
                )}

                {/* Chat Room Header */}
                <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Chatting as:</span>
                    {username ? (
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold text-blue-600 bg-blue-50 border border-blue-100 px-2.5 py-1 rounded-full">
                          {username}
                        </span>
                        <button 
                          onClick={() => { setUsername(''); localStorage.removeItem('chat_username'); }}
                          className="text-[10px] text-slate-400 hover:text-red-500 hover:underline font-bold transition-colors ml-1"
                        >
                          Change
                        </button>
                      </div>
                    ) : (
                      <span className="text-xs font-semibold text-slate-400 italic">Not set</span>
                    )}
                  </div>
                  <span className="text-xs text-slate-400 hidden sm:inline font-semibold">Real-time Student Hub</span>
                </div>
                
                {/* Chat Message Stream */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/25">
                  {messages.map(m => {
                    const isMyMessage = m.username === username;
                    const isMsgDeleted = m.isDeleted || m.text?.includes('deleted the message');

                    return (
                      <div key={m.id} className={`flex flex-col ${isMyMessage ? 'items-end' : 'items-start'} group/msg relative`}>
                        <span className="text-[11px] font-bold text-slate-400 mb-0.5 px-1">{m.username}</span>
                        
                        <div className="flex items-center gap-2 max-w-[85%] sm:max-w-[70%]">
                          {/* Message Deletion Trash Icon */}
                          {isMyMessage && !isMsgDeleted && (
                            <button 
                              onClick={() => handleDeleteMessage(m.id)}
                              className="opacity-40 sm:opacity-0 group-hover/msg:opacity-100 text-slate-400 hover:text-red-500 p-1.5 hover:bg-slate-100 rounded-lg transition-all duration-150 flex-shrink-0 order-first cursor-pointer"
                              title="Delete message"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <div className={`px-4 py-2.5 rounded-2xl shadow-3xs text-sm ${
                            isMsgDeleted
                              ? 'bg-slate-100/80 text-slate-400 border border-slate-200/50 rounded-xl italic font-medium'
                              : isMyMessage 
                                ? 'bg-blue-600 text-white rounded-tr-none' 
                                : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                          }`}>
                            {isMsgDeleted ? (
                              <span className="flex items-center gap-1.5 text-xs text-slate-400/90 font-medium select-none">
                                <span className="text-xs">🚫</span>
                                {m.text || `${m.username} deleted the message`}
                              </span>
                            ) : (
                              <>
                                {m.text && <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>}
                                
                                {/* Instant media image preview */}
                                {m.fileUrl && isImageFile(m.fileName) && (
                                  <div className="mt-2 rounded-xl overflow-hidden border border-slate-200/50 shadow-2xs max-w-full bg-slate-50">
                                    <img 
                                      src={m.fileUrl} 
                                      alt={m.fileName || 'Shared image'} 
                                      className="max-h-64 object-contain w-full hover:scale-[1.015] active:scale-99 transition-all duration-150 cursor-pointer" 
                                      onClick={() => window.open(m.fileUrl, '_blank')}
                                      referrerPolicy="no-referrer"
                                    />
                                  </div>
                                )}

                                {/* Instant media video preview */}
                                {m.fileUrl && isVideoFile(m.fileName) && (
                                  <div className="mt-2 rounded-xl overflow-hidden border border-slate-200/50 shadow-2xs max-w-full bg-black">
                                    <video 
                                      src={m.fileUrl} 
                                      controls 
                                      className="max-h-64 w-full object-contain"
                                    />
                                  </div>
                                )}

                                {m.fileUrl && (
                                  <div className="flex items-center gap-2 mt-2 pt-1">
                                    <a 
                                      href={m.fileUrl} 
                                      target="_blank" 
                                      rel="noopener noreferrer" 
                                      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs hover:opacity-95 transition-all font-bold ${
                                        isMyMessage ? 'bg-black/15 text-white hover:bg-black/25' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                      }`}
                                    >
                                      <ExternalLink className="w-3.5 h-3.5 flex-shrink-0"/>
                                      View
                                    </a>
                                    <a 
                                      href={m.fileUrl} 
                                      download={m.fileName || 'file'}
                                      className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs hover:opacity-95 transition-all font-bold ${
                                        isMyMessage ? 'bg-black/15 text-white hover:bg-black/25' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                      }`}
                                    >
                                      <Download className="w-3.5 h-3.5 flex-shrink-0"/>
                                      Download
                                    </a>
                                  </div>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Input Footer Form */}
                <form onSubmit={handleChatSend} className="p-4 bg-white border-t border-slate-100 flex gap-2">
                  <label className="cursor-pointer text-slate-400 hover:text-blue-600 hover:bg-slate-50 p-2.5 border border-slate-200 rounded-lg flex items-center justify-center transition-colors">
                    <Paperclip className="w-5 h-5" />
                    <input type="file" className="hidden" onChange={handleFileUpload} />
                  </label>
                  <Input 
                    value={chatInput} 
                    onChange={e => setChatInput(e.target.value)} 
                    placeholder={username ? "Type a message..." : "Set a username above to start chatting"} 
                    className="flex-1 h-10 border-slate-200 focus-visible:ring-blue-500 rounded-lg text-sm"
                    disabled={!username}
                  />
                  <Button type="submit" disabled={!username} className="bg-blue-600 hover:bg-blue-700 text-white h-10 px-4 rounded-lg"><Send className="w-4 h-4"/></Button>
                </form>
              </>
            )}
          </div>
        )}

        {/* AI TAB */}
        {activeTab === 'ai' && (
          <div className="flex flex-col h-[calc(100vh-190px)] min-h-[400px] bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-300">
            {aiDisabled ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4 bg-slate-50/50">
                <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center border border-red-100 text-red-500 animate-pulse">
                  <Bot className="w-8 h-8" />
                </div>
                <div className="space-y-1 max-w-sm">
                  <h3 className="text-lg font-bold text-slate-800">AI Assistant Offline</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">The AI Study Helper has been temporarily turned off by the school administrator. Please use your notes or ask a classmate in the chat if available.</p>
                </div>
              </div>
            ) : (
              <>
                 <div className="p-4 border-b border-slate-100 bg-blue-50/30 flex items-center gap-3">
                  <div className="p-1.5 bg-blue-100 rounded-lg text-blue-600">
                    <Bot className="w-5 h-5"/>
                  </div>
                  <div>
                    <h2 className="font-bold text-slate-900 text-sm">Ask Gemini AI Agent</h2>
                    <p className="text-xs text-slate-500">Ask questions, request summaries, or solve academic problems</p>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 bg-slate-50/20">
                  {aiHistory.length === 0 && (
                    <div className="text-center text-slate-400 py-12 flex flex-col items-center justify-center h-full">
                      <Bot className="w-12 h-12 mb-3 opacity-30 text-blue-500 animate-bounce" />
                      <h3 className="font-semibold text-slate-700 mb-1">Interactive Learning Assistant</h3>
                      <p className="text-xs text-slate-500 max-w-sm px-4">I can help clarify study topics, translate sentences, explain complex concepts, or summarize notes instantly.</p>
                    </div>
                  )}
                  {aiHistory.map((m, i) => (
                    <div key={i} className={`flex gap-3.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      {m.role === 'ai' && (
                        <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0 text-blue-600 shadow-3xs">
                          <Bot className="w-4 h-4"/>
                        </div>
                      )}
                      <div className={`prose prose-slate max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-sm shadow-3xs ${
                        m.role === 'user' 
                          ? 'bg-blue-600 text-white rounded-tr-none' 
                          : 'bg-white border border-slate-200 rounded-tl-none text-slate-800'
                      }`}>
                        {m.role === 'user' ? (
                          <p className="whitespace-pre-wrap">{m.text}</p>
                        ) : (
                          <div className="markdown-body">
                            <ReactMarkdown>{m.text}</ReactMarkdown>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {aiLoading && (
                    <div className="flex gap-3.5">
                      <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0 text-blue-600 animate-pulse">
                        <Bot className="w-4 h-4"/>
                      </div>
                      <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none px-4 py-3 text-xs text-slate-500 shadow-3xs flex items-center gap-2">
                        <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce" />
                        <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]" />
                        <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]" />
                        <span className="ml-1 font-medium">Gemini is thinking...</span>
                      </div>
                    </div>
                  )}
                </div>

                <form onSubmit={handleAiSubmit} className="p-4 bg-white border-t border-slate-100 flex gap-2">
                  <Input 
                    value={aiInput} 
                    onChange={e => setAiInput(e.target.value)} 
                    placeholder="Ask anything..." 
                    className="flex-1 h-10 border-slate-200 focus-visible:ring-blue-500 rounded-lg text-sm"
                    disabled={aiLoading}
                  />
                  <Button type="submit" disabled={aiLoading} className="bg-blue-600 hover:bg-blue-700 text-white h-10 px-4 rounded-lg"><Send className="w-4 h-4"/></Button>
                </form>
              </>
            )}
          </div>
        )}

      </main>
      {viewingFile && (
        <TextFileViewer 
          content={viewingFile.content} 
          fileName={viewingFile.name} 
          onClose={() => setViewingFile(null)} 
        />
      )}
    </div>
  );
}

